# Student Management System - Spring Boot Assignment

## Requirements
- Java 17 or newer
- Maven (or open this project in IntelliJ IDEA / VS Code with Java extensions)

## Run the website
1. Open this folder in your IDE.
2. Run `SpringBootWebApplication.java`, or open a terminal in this folder and run:
   - Windows: `mvnw.cmd spring-boot:run` (if you add the Maven wrapper), or `mvn spring-boot:run` if Maven is installed.
3. Open http://localhost:8080 in your browser.

## Pages
- Home: http://localhost:8080/
- Project Creator: http://localhost:8080/about.html
- Product: http://localhost:8080/product.html
- Features: http://localhost:8080/features.html
- Contact: http://localhost:8080/contact.html

## Before submitting
- Check the year/course details on `about.html`.
- Replace the example email and phone details on `contact.html`.
- This is a static informational website; adding, updating, deleting, or searching actual student records is not implemented.
